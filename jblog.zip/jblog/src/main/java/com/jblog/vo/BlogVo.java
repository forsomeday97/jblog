package com.jblog.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class BlogVo {
	private String id;
	private String blogtitle;
	private String logofile;
	private String username;
}
