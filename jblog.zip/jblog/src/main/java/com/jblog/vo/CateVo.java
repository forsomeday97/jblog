package com.jblog.vo;

import lombok.Data;

@Data
public class CateVo {
	private int cateno;
	private String id;
	private String catename;
	private String description;	//설명
	private String regdate;
	private int totalpost;
	

	
	
}
